#!/bin/bash

# for viewing
openroad -gui scripts/show.tcl

